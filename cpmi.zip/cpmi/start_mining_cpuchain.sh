#!/bin/sh
while [ 1 ]; do
./cpuminer -a cpupower -o stratum+tcp://cpu-pool.com:63388 -u WALLET_ADDRESS
sleep 10
done
